﻿param(
    [int]$Auto = 0,
    [switch]$NoOpen
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$env:PYTHONUTF8 = "1"
$env:PYTHONPATH = $root
$WebVersion = "2026-11-19.25"
try { $Host.UI.RawUI.WindowTitle = "教案工坊 Demo" } catch {}

$DemoOut = Join-Path $root "demo_run"
$DemoDocx = Join-Path $DemoOut "ch01_第一章_走进人工智能\教案.docx"
$DemoReport = Join-Path $DemoOut "ch01_第一章_走进人工智能\质检报告.md"

function Test-Ollama {
    try {
        $r = Invoke-WebRequest -Uri "http://127.0.0.1:11435/api/tags" -UseBasicParsing -TimeoutSec 2
        return $r.StatusCode -eq 200
    } catch {
        return $false
    }
}

function Find-Python {
    $candidates = @()
    $venv = Join-Path $root ".venv\Scripts\python.exe"
    if (Test-Path $venv) { $candidates += $venv }
    $pf = Join-Path $env:ProgramFiles "Python312\python.exe"
    if (Test-Path $pf) { $candidates += $pf }
    $local = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
    if (Test-Path $local) { $candidates += $local }
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd) { $candidates += $cmd.Source }

    foreach ($py in $candidates) {
        try {
            & $py -c "import docx" 2>$null
            if ($LASTEXITCODE -eq 0) { return $py }
        } catch {}
    }
    return $null
}

function Ensure-Ollama {
    if (Test-Ollama) {
        Write-Host "  [OK] 本地模型服务已就绪：127.0.0.1:11435" -ForegroundColor Green
        return $true
    }
    if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
        Write-Host "  [ERROR] 找不到 ollama，请先安装 Ollama。" -ForegroundColor Red
        return $false
    }
    Write-Host "  正在启动本地模型服务（新窗口，请保持打开）..." -ForegroundColor Yellow
    $env:OLLAMA_HOST = "127.0.0.1:11435"
    $env:OLLAMA_CONTEXT_LENGTH = "16384"
    $env:OLLAMA_KEEP_ALIVE = "30m"
    try {
        $ollama = (Get-Command ollama).Source
        Start-Process -FilePath $ollama -ArgumentList @("serve") -WorkingDirectory $root
    } catch {
        Write-Host "  [ERROR] 启动 ollama serve 失败：$($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    for ($i = 0; $i -lt 60; $i++) {
        Start-Sleep -Seconds 1
        if (Test-Ollama) {
            Write-Host "  [OK] 本地模型服务已启动。" -ForegroundColor Green
            return $true
        }
        if ($i % 5 -eq 4) { Write-Host "  等待模型服务启动..." -ForegroundColor DarkGray }
    }
    Write-Host "  [ERROR] 等待 60 秒仍未启动，请手动运行 scripts\start_ollama_16k.cmd 查看报错。" -ForegroundColor Red
    return $false
}

function Ensure-Model {
    $env:OLLAMA_HOST = "127.0.0.1:11435"
    try {
        $list = (& ollama list 2>$null | Out-String)
    } catch {
        $list = ""
    }
    if ($list -match "qwen2\.5:7b") {
        Write-Host "  [OK] 模型 qwen2.5:7b 已安装。" -ForegroundColor Green
        return $true
    }
    Write-Host "  [WARN] 没有找到 qwen2.5:7b，需要下载约 4.7GB。" -ForegroundColor Yellow
    $answer = Read-Host "  现在下载吗？(Y/N)"
    if ($answer -notmatch "^[Yy]") { return $false }
    & ollama pull qwen2.5:7b
    return ($LASTEXITCODE -eq 0)
}

function Run-Demo {
    param([switch]$NoOpen)

    Write-Host ""
    Write-Host "=== 1. 检查环境 ===" -ForegroundColor Cyan
    $py = Find-Python
    if (-not $py) {
        Write-Host "  [ERROR] 找不到已安装 python-docx 的 Python 3.12。" -ForegroundColor Red
        Write-Host "  请先运行 scripts\setup.cmd，或检查 VS Code 解释器。" -ForegroundColor Yellow
        return
    }
    Write-Host "  [OK] Python：$py" -ForegroundColor Green

    if (-not (Ensure-Ollama)) { return }
    if (-not (Ensure-Model)) { return }

    Write-Host ""
    Write-Host "=== 2. 生成教案（示例：第一章，2 课时）===" -ForegroundColor Cyan
    Write-Host "  首次生成约 2-4 分钟；有缓存时会很快。" -ForegroundColor DarkGray
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $cliArgs = @(
        "-m", "jiaoan", "run",
        "--textbook", "examples\textbook_demo.md",
        "--template", "examples\templates\教案模板_表格式.docx",
        "--brief", "examples\brief_demo.json",
        "--out", "demo_run",
        "--chapters", "ch01",
        "--periods", "2",
        "--no-review"
    )
    & $py @cliArgs
    $code = $LASTEXITCODE
    $sw.Stop()

    Write-Host ""
    if (Test-Path $DemoDocx) {
        $size = [math]::Round((Get-Item $DemoDocx).Length / 1KB, 0)
        Write-Host "=== 3. 完成 ===" -ForegroundColor Cyan
        Write-Host "  用时：$([math]::Round($sw.Elapsed.TotalSeconds, 0)) 秒" -ForegroundColor Gray
        Write-Host "  教案：$DemoDocx（$size KB）" -ForegroundColor Green
        Write-Host "  质检：$DemoReport" -ForegroundColor Green
        if ($code -eq 3) {
            Write-Host "  [WARN] 质检有硬错误，请先看质检报告；仍为你打开草稿。" -ForegroundColor Yellow
        }
        if (-not $NoOpen) {
            try {
                Start-Process $DemoDocx
                Write-Host "  已用 Word（或默认应用）打开教案。" -ForegroundColor Gray
            } catch {
                Start-Process $DemoOut
                Write-Host "  没能直接打开 DOCX，已打开输出文件夹。" -ForegroundColor Yellow
            }
        }
    } else {
        Write-Host "  [ERROR] 生成失败，退出码 $code。请看上方日志。" -ForegroundColor Red
    }
}

function Stop-StaleWeb {
    try {
        $conn = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction Stop | Select-Object -First 1
        if (-not $conn) { return $true }
        $ownerPid = [int]$conn.OwningProcess
        $procInfo = Get-CimInstance Win32_Process -Filter "ProcessId=$ownerPid" -ErrorAction Stop
        if ($procInfo.CommandLine -match "jiaoan.*web") {
            Write-Host "  检测到旧版网页服务，正在关闭并重启（旧任务的 Word 仍可从任务目录恢复）..." -ForegroundColor Yellow
            Stop-Process -Id $ownerPid -Force -ErrorAction Stop
            Start-Sleep -Seconds 1
            return $true
        }
        Write-Host "  [ERROR] 端口 8765 被其他程序占用：$($procInfo.Name)（PID $ownerPid）" -ForegroundColor Red
    } catch {
        Write-Host "  关闭旧网页服务失败：$($_.Exception.Message)" -ForegroundColor Red
    }
    return $false
}

function Open-UploadPage {
    Write-Host ""
    Write-Host "=== 教师上传页 ===" -ForegroundColor Cyan
    $py = Find-Python
    if (-not $py) {
        Write-Host "  [ERROR] 找不到可用的 Python 3.12。" -ForegroundColor Red
        return
    }

    $cfg = $null
    try {
        $cfg = Invoke-RestMethod -Uri "http://127.0.0.1:8765/api/config" -TimeoutSec 2
    } catch {}
    if ($cfg) {
        if ($cfg.web_version -eq $WebVersion) {
            Start-Process "http://127.0.0.1:8765"
            Write-Host "  上传页已经在运行，已打开浏览器。" -ForegroundColor Green
            return
        }
        if (-not (Stop-StaleWeb)) {
            Write-Host "  请手动关闭旧的 Python 网页窗口，再双击本快捷方式。" -ForegroundColor Red
            return
        }
    }

    Write-Host "  正在新窗口启动上传页..." -ForegroundColor Yellow
    Start-Process -FilePath $py -ArgumentList @("-m", "jiaoan", "web", "--port", "8765") -WorkingDirectory $root
    $ready = $false
    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 500
        try {
            $c = Invoke-RestMethod -Uri "http://127.0.0.1:8765/api/config" -TimeoutSec 1
            if ($c.web_version -eq $WebVersion) { $ready = $true; break }
        } catch {}
    }
    if (-not $ready) {
        Write-Host "  [ERROR] 上传页启动失败，请查看新开的 Python 窗口报错。" -ForegroundColor Red
        return
    }
    Start-Process "http://127.0.0.1:8765"
    Write-Host "  已打开 http://127.0.0.1:8765（版本 $WebVersion）" -ForegroundColor Green
    Write-Host "  关闭新开的 Python 窗口即可停止服务。" -ForegroundColor DarkGray
}

function Check-Env {
    Write-Host ""
    Write-Host "=== 环境检查 ===" -ForegroundColor Cyan
    $py = Find-Python
    if ($py) {
        Write-Host "  [OK] Python：$py" -ForegroundColor Green
        & $py -m jiaoan doctor
    } else {
        Write-Host "  [ERROR] 没有找到带 python-docx 的 Python。" -ForegroundColor Red
    }
    Write-Host ""
    if (Test-Ollama) {
        Write-Host "  [OK] 本地模型服务：127.0.0.1:11435" -ForegroundColor Green
        $env:OLLAMA_HOST = "127.0.0.1:11435"
        & ollama ps
    } else {
        Write-Host "  [WARN] 本地模型服务未启动。运行 scripts\start_ollama_16k.cmd。" -ForegroundColor Yellow
    }
}

if ($Auto -eq 1) {
    Run-Demo -NoOpen:$NoOpen
    exit 0
}
if ($Auto -eq 2) {
    Open-UploadPage
    exit 0
}

while ($true) {
    Clear-Host
    Write-Host "==============================================" -ForegroundColor DarkCyan
    Write-Host "        教案工坊 Demo（双击即可运行）" -ForegroundColor Cyan
    Write-Host "==============================================" -ForegroundColor DarkCyan
    Write-Host "  1. 运行示例：自动生成 2 课时教案并打开 Word"
    Write-Host "  2. 打开教师上传页：用自己的教材/模板，可选学校 API"
    Write-Host "  3. 检查环境（Python / 模型 / 服务）"
    Write-Host "  0. 退出"
    Write-Host ""
    $choice = Read-Host "  请选择 [1]"
    if ([string]::IsNullOrWhiteSpace($choice)) { $choice = "1" }

    switch ($choice.Trim()) {
        "1" { Run-Demo; Read-Host "`n按 Enter 返回菜单" | Out-Null }
        "2" { Open-UploadPage; Read-Host "`n按 Enter 返回菜单" | Out-Null }
        "3" { Check-Env; Read-Host "`n按 Enter 返回菜单" | Out-Null }
        "0" { return }
        default {
            Write-Host "  请输入 0-3。" -ForegroundColor Yellow
            Start-Sleep -Seconds 1
        }
    }
}

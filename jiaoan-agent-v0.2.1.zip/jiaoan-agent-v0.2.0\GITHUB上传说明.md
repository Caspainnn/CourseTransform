# GitHub 上传说明

版本：`0.2.0`（Web 构建 `2026-11-19.25`）

这个目录是可以直接上传的完整项目副本，不含本机任务、缓存、密钥和临时文件。

## 已包含

```text
jiaoan/                 核心代码
tests/                  测试（23 个）
examples/               示例教材、模板、配图
schemas/                lesson_plan JSON Schema
docs/                   设计文档与截图
scripts/                Windows 启动/环境脚本
demo/ demo_qwen/ demo_figures/
demo_template/          真实教材 + 模板生成的学时教案示例
README.md               项目说明
requirements.txt / pyproject.toml
RUN_DEMO.cmd / OPEN_WEB.cmd
.env.example
.gitignore
VERSION
```

## 已排除

- `.env`：本机 API Key / Base URL / 模型配置；
- `web_jobs/`：网页任务和上传文件；
- `.jiaoan_cache/`：OCR 与模型响应缓存；
- `out*`、`demo_run/`：运行输出；
- `tmp_*`、`__pycache__`、`*.pyc`、`*.log`；
- `*.lnk`：Windows 桌面快捷方式，指向本机路径，不适合放进仓库。

## 上传方式一：GitHub 网页拖拽

1. 在 GitHub 新建 repository，例如 `jiaoan-agent`；
2. 不要勾选 “Add a README”；
3. 把本目录里的**所有文件和文件夹**拖进上传页面；
4. Commit。

## 上传方式二：Git 命令行

```powershell
cd <这个目录>
git init
git add .
git commit -m "feat: 教案工坊 v0.2.0（整章拆学时、9/6 栏模板、图筛、直接 Word）"
git branch -M main
git remote add origin https://github.com/<your-name>/jiaoan-agent.git
git push -u origin main
```

## 上传后怎么跑

```powershell
python -m pip install -r requirements.txt
copy .env.example .env
# 编辑 .env，填学校 DeepSeek 或本机 Ollama
python -m jiaoan web --port 8765 --open
```

或双击：

```text
OPEN_WEB.cmd
RUN_DEMO.cmd
```

## 不要提交的内容

- `.env` 里的 `JIAOAN_API_KEY`；
- 学校网关的 Key；
- `web_jobs/` 里老师上传的教材、模板和图片；
- 任何个人桌面路径（本项目源码和文档已改成相对路径）。

## 大文件说明

单个文件都小于 25 MB，可以直接网页上传。如果以后要放更大的模型或视频，使用 Git LFS 或外链，不要直接提交。

@echo off
setlocal
set "OLLAMA_HOST=127.0.0.1:11435"
set "OLLAMA_CONTEXT_LENGTH=16384"
set "OLLAMA_KEEP_ALIVE=30m"
echo 启动 Ollama（16k 上下文，端口 11435）...
echo 保持这个窗口开着；另开一个终端运行 jiaoan。
ollama serve

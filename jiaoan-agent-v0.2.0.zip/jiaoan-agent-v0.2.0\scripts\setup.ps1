# 创建本地虚拟环境并安装依赖（Windows PowerShell）
$ErrorActionPreference = "Stop"

$python = "python"
try {
    & $python --version | Out-Null
} catch {
    Write-Error "找不到 python，请先安装 Python 3.10+。"
    exit 1
}

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    & $python -m venv .venv
}
& ".\.venv\Scripts\python.exe" -m pip install --upgrade pip
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt

Write-Host ""
Write-Host "安装完成。运行示例："
Write-Host '  .\.venv\Scripts\python.exe -m jiaoan run --textbook examples\textbook_demo.md --template examples\templates\教案模板_表格式.docx --brief examples\brief_demo.json --out out_demo --offline'

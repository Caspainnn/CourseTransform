# 本机真实模型实跑结果

这一份不是离线骨架，而是用本机显卡真实跑出来的 2 课时教案。

## 运行环境

- Python：`C:\Program Files\Python312\python.exe`（3.12.6，VS Code 当前解释器）
- python-docx：1.2.0（`pip install --user python-docx`）
- python-pptx：1.0.2（下游示例用）
- Ollama：0.24.0，本机 RTX 4060 Laptop 8GB
- 模型：`qwen2.5:7b`（Q4，4.7GB）
- 服务：`OLLAMA_HOST=127.0.0.1:11435`，`OLLAMA_CONTEXT_LENGTH=16384`

## 运行命令

```powershell
# 终端 1：启动 16k 上下文服务，保持窗口
.\scripts\start_ollama_16k.cmd

# 终端 2：生成
.\scripts\jiaoan.cmd run `
  --textbook examples\textbook_demo.md `
  --template examples\templates\教案模板_表格式.docx `
  --brief examples\brief_demo.json `
  --out demo_qwen `
  --chapters ch01 `
  --periods 2 `
  --no-review
```

## 结果

- 章节：第一章 走进人工智能
- 课时：2 课时 × 45 分钟
- 教学环节：7 个（第 1 课时 4 个，第 2 课时 3 个）
- 教材小节覆盖：3/3，100%
- 教学目标：3 条（知识/技能、思维/技能、价值）
- 教材引用：3 条，全部可回查原文
- PPT 提纲：7 页
- 质检：通过（3 条建议，均为 PPT 单页要点少于 2 条，不影响教案 DOCX）

## 文件

- `ch01_第一章_走进人工智能/教案.docx`：套用表格式模板的成品
- `ch01_第一章_走进人工智能/教案.md`：Markdown 版
- `ch01_第一章_走进人工智能/lesson_plan.json`：下游 PPT 的结构化契约
- `ch01_第一章_走进人工智能/质检报告.md`：硬指标、目标对齐、教材覆盖、引用核对
- `manifest.json`：批量汇总

## 已知小问题

- 2 课时共用一张“教学过程”表，环节名带了“第 1 课时 / 第 2 课时”前缀；如果学校模板要求每课时一张表，需要再适配。
- 质检报告里 3 条建议是 PPT 提纲单页要点偏少；做 PPT 时补足即可。
- 生成内容仍需学科教师复核，尤其是教材版本、学情和作业量。

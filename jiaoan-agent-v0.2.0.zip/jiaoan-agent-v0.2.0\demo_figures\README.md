# 教材配图实跑结果

本机 Qwen2.5-7B 真实生成、带教材配图的 1 课时教案。

## 输入

- 教材：`examples/textbook_with_images.md`
- 配图：`examples/figures/fig-1-1.png`、`fig-1-2.png`
- 模板：`examples/templates/教案模板_表格式.docx`

## 处理过程

1. 教材 md 里用 `![图注](figures/fig-1-1.png)` 引用图片；
2. 上传图片按文件名与 md 引用匹配；
3. RapidOCR 识别图片文字；
4. 模型结合图注、OCR、小节和教学环节，分配 `phase_id` 并写 8-30 字图注；
5. DOCX 把图片放进对应环节“教师活动”单元格下方；
6. 验收报告通过 SHA256 检查图片确实嵌入 DOCX。

## 结果

- 1 课时 45 分钟
- 2 张配图全部嵌入
- 验收通过
- 文件：`教案.docx`、`模板说明书.md`、`验收报告.md`、`图片清单.json`、`images/`

## 重新生成

```powershell
.\scripts\jiaoan.cmd run `
  --textbook examples\textbook_with_images.md `
  --images examples\figures `
  --template examples\templates\教案模板_表格式.docx `
  --brief examples\brief_demo.json `
  --out demo_figures `
  --chapters ch01 `
  --periods 1 `
  --no-review
```

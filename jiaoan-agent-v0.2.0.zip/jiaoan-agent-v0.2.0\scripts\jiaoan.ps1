# 在当前工作区运行 jiaoan，自动选择一个已安装 python-docx 的 Python。
# 用法：.\scripts\jiaoan.ps1 run --textbook ... 或 .\scripts\jiaoan.ps1 --help
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = $root
$env:PYTHONUTF8 = "1"

$candidates = @()
$venv = Join-Path $root ".venv\Scripts\python.exe"
if (Test-Path $venv) { $candidates += $venv }
if ($env:JIAOAN_PYTHON) { $candidates += $env:JIAOAN_PYTHON }
$vscodePy = "C:\Program Files\Python312\python.exe"
if (Test-Path $vscodePy) { $candidates += $vscodePy }
$dsh = Join-Path $env:USERPROFILE ".dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if (Test-Path $dsh) { $candidates += $dsh }

foreach ($py in $candidates) {
    try {
        & $py -c "import docx" 2>$null
        if ($LASTEXITCODE -eq 0) {
            & $py -m jiaoan @args
            exit $LASTEXITCODE
        }
    } catch { }
}

# 最后尝试 PATH 里的 python；如果缺 python-docx，会给出明确报错
& python -m jiaoan @args
exit $LASTEXITCODE

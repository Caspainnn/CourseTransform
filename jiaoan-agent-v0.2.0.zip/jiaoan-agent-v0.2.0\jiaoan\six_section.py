from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm
from docx.table import Table
from docx.text.paragraph import Paragraph

from .nine_section import (
    _asset_caption,
    _fill_table,
    _image_placements,
    _set_cell_text,
    _set_para_text,
    build_nine_section_data,
)
from .template import TemplateSpec
from .textbook import Chapter


SIX_LABELS = ["课程基本信息", "课程简介", "教学内容", "案例教学实施过程", "课堂小结与学习评价", "教学效果及反思"]


def is_six_section(spec: TemplateSpec) -> bool:
    if spec.kind != "docx" or spec.doc is None:
        return False
    from .utils import normalize_label

    labels = []
    for p in spec.doc.paragraphs:
        text = normalize_label(p.text)
        if text in SIX_LABELS or any(text.startswith(lbl) for lbl in SIX_LABELS):
            if text not in labels:
                labels.append(text)
    if len(labels) < 6 or not all(any(x.startswith(lbl) for x in labels) for lbl in SIX_LABELS):
        return False
    if len(spec.doc.tables) != 5:
        return False
    headers = ["|".join(c.text.strip() for c in t.rows[0].cells) for t in spec.doc.tables if t.rows]
    shapes = [(len(t.rows), len(t.columns)) for t in spec.doc.tables]
    return (
        shapes[:5] == [(6, 3), (4, 3), (4, 3), (9, 4), (4, 3)]
        and any(h.startswith("项目|内容|实施安排") for h in headers)
        and any(h.startswith("目标维度|可检测的学习行为|学习证据") for h in headers)
        and any(h.startswith("数据对象|形状或含义|检查要点") for h in headers)
        and any(h.startswith("环节|时间|教师推进|学生任务与检查点") for h in headers)
        and any(h.startswith("观察维度|课后核对依据|实际记录") for h in headers)
    )


def _summary(value: Any, limit: int = 60) -> str:
    """表格单元格只保留必要短句，避免把整段师生活动塞进 4 列表格。"""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r"\[L\d+(?:\s*-\s*L?\d+)?\]", "", text)
    text = re.sub(r"（\s*教材原文[^）]*）", "", text)
    if len(text) <= limit:
        return text
    cut = text[:limit]
    for mark in ("。", "；", "，", ";", ",", " "):
        pos = cut.rfind(mark)
        if pos >= limit * 0.55:
            return cut[:pos].rstrip("，；,; ") + "…"
    return cut.rstrip() + "…"


def _join(value: Any, sep: str = "；") -> str:
    if isinstance(value, list):
        return sep.join(str(x).strip() for x in value if str(x).strip())
    return str(value or "").strip()


def build_six_data(
    plan: dict[str, Any],
    chapter: Chapter,
    assets: list[Any] | None = None,
    lesson_index: int = 0,
    lesson_no: int = 1,
) -> dict[str, Any]:
    base = build_nine_section_data(plan, chapter, assets, lesson_index, lesson_no)
    m = base["meta"]
    objectives = base["objectives"]
    rows = []
    for label, key in (("知识目标", "knowledge"), ("能力目标", "method"), ("价值目标", "safety")):
        rows.append([label, _summary("；".join(objectives.get(key, [])[:2]), 48), "课堂追问、任务单与可追溯记录"])
    difficulties = base["difficulties"]
    first = difficulties[0] if difficulties else {}
    data_rows = [
        ["输入与样本", f"{m['chapter_topic'].splitlines()[0]}的数据/案例", "核对来源、形状与数量"],
        ["标签与目标", "真实标签、预测标签或任务目标", "区分特征、标签与预测结果"],
        ["输出与评价", "准确率、损失、图表或任务作品", "至少两类证据，写明条件与局限"],
    ]
    if "投毒" in m.get("lesson_title", ""):
        data_rows = [
            ["MNIST 样本", "(60000, 785) / (10000, 785)；784 像素 + 1 标签", "像素范围 0–255；标签 0–9"],
            ["投毒样本与标签", "按 0% / 50% / 100% 修改训练集标签", "只改训练集；测试集保持干净"],
            ["模型输出与评价", "10 类得分、准确率、损失曲线", "对照比例/学习率，记录参数与曲线"],
        ]
    phases = base["phases"][:8]
    images = [asset for _, asset in base.get("image_placements", [])][:3]
    return {
        **base,
        "meta": m,
        "course_name": m["course_name"],
        "content": m["chapter_topic"].replace("\n", " / "),
        "audience": m["audience"],
        "method": m.get("lesson_type") or "示范、短程运行、对照研讨",
        "info": m.get("teacher_place") or "教师：____________　时间地点：____________",
        "objective_rows": rows,
        "data_rows": data_rows,
        "phases": phases,
        "images": images,
        "first_difficulty": first,
    }


def _set_cell_text_preserve(cell, text: str) -> None:
    _set_cell_text(cell, text)


def _fill_table_rows(table: Table, rows: list[list[str]]) -> None:
    for r, values in enumerate(rows, start=1):
        if r >= len(table.rows):
            break
        for c, value in enumerate(values):
            if c < len(table.rows[r].cells):
                _set_cell_text_preserve(table.rows[r].cells[c], value)


def _replace_picture(p: Paragraph, asset: Any, caption_p: Paragraph | None, base_dir: str | Path | None, number: int = 1) -> None:
    from docx.oxml.ns import qn

    for child in list(p._p):
        if child.tag != qn("w:pPr"):
            p._p.remove(child)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    try:
        run = p.add_run()
        path = Path(str(getattr(asset, "output_path", "") or getattr(asset, "path", "")))
        if base_dir and not path.is_absolute():
            path = Path(base_dir) / path
        if path.is_file():
            try:
                from PIL import Image

                with Image.open(path) as im:
                    iw, ih = im.size
                max_w, max_h = 10.5, 8.0
                if iw / max(1, ih) > max_w / max_h:
                    width, height = max_w, max_w * ih / max(1, iw)
                else:
                    width, height = max_h * iw / max(1, ih), max_h
                run.add_picture(str(path), width=Cm(width), height=Cm(height))
            except Exception:
                run.add_picture(str(path), width=Cm(9.0))
        else:
            p.add_run(f"（配图缺失：{getattr(asset, 'filename', '')}）")
    except Exception as exc:
        p.add_run(f"（配图插入失败：{exc}）")
    if caption_p is not None:
        _set_para_text(caption_p, f"图{number} {_asset_caption(asset)}")


def _remove_para(p: Paragraph | None) -> None:
    if p is not None:
        try:
            p._p.getparent().remove(p._p)
        except Exception:
            pass


def render_six_section(
    spec: TemplateSpec,
    data: dict[str, Any],
    out_path: str | Path,
    base_dir: str | Path | None = None,
) -> Path:
    """严格按“6 栏正文表格仿宋版”模板原位替换，保留 4 列教学过程表与正文内嵌图。"""
    doc = Document(str(spec.path))
    paras = doc.paragraphs
    tables = doc.tables
    if len(paras) < 59 or len(tables) < 5:
        raise ValueError("模板段落/表格数量与预期不一致，无法按 6 栏模板渲染")

    # 标题与副标题
    _set_para_text(paras[0], data["meta"]["chapter_topic"].splitlines()[0])
    _set_para_text(paras[1], f"第{data['meta'].get('lesson_no', 1)}学时 {data['meta']['lesson_title']}")

    # 表1 课程基本信息（3 列）
    _fill_table_rows(
        tables[0],
        [
            ["课程名称", data["course_name"], "总计32学时"],
            ["授课内容", _summary(data["content"], 46), f"本次1学时，{data['meta'].get('duration_minutes', 45)}分钟"],
            ["教学对象", data["audience"], "已完成先修内容"],
            ["教学方式", data["method"], "两人一组，操作与核查交换"],
            ["授课信息", "教师：____________", "时间地点：____________"],
        ],
    )
    # 表2 教学目标（3 列）
    _fill_table_rows(tables[1], data["objective_rows"])
    # 表3 数据对象（3 列）
    _fill_table_rows(tables[2], data["data_rows"])
    # 表5 反思（3 列）
    _fill_table_rows(
        tables[4],
        [[r["observation"], _summary(r["risk"], 52), ""] for r in data["reflection"][:4]],
    )
    # 表4 教学过程（4 列：环节/时间/教师推进/学生任务与检查点）
    phase_rows = []
    for p in data["phases"][:8]:
        phase_rows.append([
            _summary(p["name"], 14),
            f"{p['minutes']}分钟",
            _summary(p["teacher_activity"], 62),
            _summary(p["student_activity"], 52),
        ])
    _fill_table_rows(tables[3], phase_rows)

    # 6 栏正文：保留模板的栏目/子标题，只替换正文
    replacements = {
        3: f"本课的授课内容、教学对象及实施安排如下表1所示；本学时聚焦“{data['meta']['lesson_title']}”。",
        7: f"本课承接前一时段的先修内容，以教材“{data['meta']['chapter_topic'].splitlines()[0]}”为载体，完成“数据—模型—训练—评价”的完整实践，重点放在读懂流程、核对数据与解释结果。",
        9: " ".join(
            [
                "知识：" + "；".join(data["objectives"]["knowledge"][:1]),
                "能力：" + "；".join(data["objectives"]["method"][:1]),
                "价值：" + "；".join(data["objectives"]["safety"][:1]),
            ]
        ),
        10: f"主要资料：{data['preparation']['materials']}。",
        13: f"围绕“{data['meta']['lesson_title']}”组织教学：先核对数据与标签，再走通一次最小流程，最后用对照结果说明结论边界。{data['preparation']['environment']}",
        15: "本次教学目标及对应的学习证据如下表2所示，可据此检查知识、能力和价值目标的达成情况。",
        18: (f"重点：{_join(data['key_points'][:3])}。难点：{data['first_difficulty'].get('point', '')}——{data['first_difficulty'].get('stuck', '')}；突破手段：{data['first_difficulty'].get('strategy', '')}。").replace("。；", "；"),
        20: f"{data['preparation']['environment']} 课前完成环境自检，准备已调试 Notebook、同条件记录和离线缓存。",
        23: f"提问：本课的核心对象、标签和评价指标分别是什么？先核验数据，再运行流程。{data['phases'][0]['teacher_activity']}",
        26: f"如上图1所示，先确认数据来源、形状与标签，再进入模型流程。{data['phases'][1]['intent']}",
        30: data["phases"][2]["teacher_activity"] + data["phases"][2]["student_activity"],
        33: f"如上图2所示，一轮流程的关键是分清每一步更新了谁、保留了哪些量。{data['phases'][2]['intent']}",
        34: f"读图追问：{data['phases'][3]['teacher_activity']} 参考要点：先看输入输出，再看参数更新与评价证据。",
        36: data["phases"][4]["teacher_activity"] + data["phases"][4]["student_activity"],
        39: f"如上图3所示，结果图要结合数据条件、参数和评价口径一起读；单次结果不能直接外推。{data['phases'][4]['intent']}",
        40: f"读图要点：{data['phases'][5]['student_activity']}",
        41: f"课堂任务：{data['phases'][5]['teacher_activity']}",
        44: f"两人一组，按任务单完成操作、记录与交换核查；短运行超时改用同条件缓存，并标明来源。{data['phases'][6]['student_activity']}",
        46: f"本学时共{data['meta'].get('duration_minutes', 45)}分钟，各环节的时间分配、教师活动和学生任务如下表4所示。",
        50: _join(list(data["board"].values()), "；"),
        52: f"退出题：{data['homework']['exit_ticket']}",
        54: f"{_join(data['homework']['practice'])} 评分：{data['homework']['scoring']}",
        56: "课后需要核对的观察维度和记录要求如下表5所示，实际记录应依据真实授课情况填写。",
        58: _join([r["risk"] for r in data["reflection"][:4]], "；"),
    }
    for idx, text in replacements.items():
        if idx < len(paras):
            text = str(text).replace("。。", "。").replace("。；", "；").replace("评分：评分：", "评分：")
            _set_para_text(paras[idx], text)

    # 正文内嵌图：模板的三处图位（24/25、31/32、37/38）
    slots = [(24, 25), (31, 32), (37, 38)]
    for i, (img_idx, cap_idx) in enumerate(slots):
        img_p = paras[img_idx] if img_idx < len(paras) else None
        cap_p = paras[cap_idx] if cap_idx < len(paras) else None
        if i < len(data["images"]):
            if img_p is not None:
                _replace_picture(img_p, data["images"][i], cap_p, base_dir, i + 1)
        else:
            _remove_para(img_p)
            _remove_para(cap_p)

    # 模板里部分栏目标题带“段前分页”；生成内容长短不一，保留会留下整页空白。
    # 分页是排版细节，不是教案结构；这里统一取消段前分页，让内容自然接排。
    for p in doc.paragraphs:
        try:
            p.paragraph_format.page_break_before = False
        except Exception:
            pass

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out))
    return out

# 离线演示稿

这里是 `--offline` 模式生成的两章示例，用来证明：

- 教材 md 能正确切章；
- 表格式模板的字段、信息表和教学过程表能填进去；
- DOCX / Markdown / JSON / 质检报告能同时产出；
- 下游 PPT 只需要读 `lesson_plan.json`。

> **注意**：离线稿由规则骨架生成，只用于流程联调，不是教学成品。正式教案请配置 API Key 后去掉 `--offline` 重新生成。

打开：

- `ch01_第一章_走进人工智能/教案.docx`
- `ch01_第一章_走进人工智能/lesson_plan.json`
- `ch01_第一章_走进人工智能/质检报告.md`

下游 PPT 只需要读 `lesson_plan.json`，示例：

```powershell
python examples\consume_plan.py "demo\ch01_第一章_走进人工智能\lesson_plan.json"
```

重新生成：

```powershell
python -m jiaoan run `
  --textbook examples\textbook_demo.md `
  --template examples\templates\教案模板_表格式.docx `
  --brief examples\brief_demo.json `
  --out demo `
  --offline
```

@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\demo.ps1" -Auto 2
if errorlevel 1 pause
exit /b %ERRORLEVEL%

# 启动 16k 上下文的 Ollama（PowerShell）
$env:OLLAMA_HOST = "127.0.0.1:11435"
$env:OLLAMA_CONTEXT_LENGTH = "16384"
$env:OLLAMA_KEEP_ALIVE = "30m"
Write-Host "启动 Ollama（16k 上下文，端口 11435）..."
ollama serve

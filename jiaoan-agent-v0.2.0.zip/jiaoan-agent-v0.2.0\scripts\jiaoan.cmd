@echo off
setlocal
set "ROOT=%~dp0.."
set "PYTHONPATH=%ROOT%"
set "PYTHONUTF8=1"

if exist "%ROOT%\.venv\Scripts\python.exe" (
  "%ROOT%\.venv\Scripts\python.exe" -m jiaoan %*
  exit /b %ERRORLEVEL%
)
if defined JIAOAN_PYTHON (
  "%JIAOAN_PYTHON%" -m jiaoan %*
  exit /b %ERRORLEVEL%
)
if exist "C:\Program Files\Python312\python.exe" (
  "C:\Program Files\Python312\python.exe" -c "import docx" >nul 2>&1
  if not errorlevel 1 (
    "C:\Program Files\Python312\python.exe" -m jiaoan %*
    exit /b %ERRORLEVEL%
  )
)
if exist "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" (
  "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" -m jiaoan %*
  exit /b %ERRORLEVEL%
)

python -m jiaoan %*
exit /b %ERRORLEVEL%
